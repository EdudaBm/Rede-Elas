<?php

use PHPUnit\Framework\TestCase;
use App\Funcionario;
use App\Gerente;
use App\Desenvolvedor;

class FuncionarioTest extends TestCase
{
    public function testFuncionarioBasico()
    {
        $f = new Funcionario("Ana", 3000);
        $this->assertEquals("Ana", $f->getNome());
        $this->assertEquals(3000, $f->getSalario());
        $this->assertEquals(36000, $f->calcularSalarioAnual());
    }

    public function testGerente()
    {
        $g = new Gerente("Carlos", 5000, 10000);
        $this->assertEquals("Carlos", $g->getNome());
        $this->assertEquals(5000, $g->getSalario());
        $this->assertEquals(10000, $g->getBonusAnual());
        $this->assertEquals(70000, $g->calcularSalarioAnual());
    }

    public function testDesenvolvedor()
    {
        $d = new Desenvolvedor("Bia", 4000, "PHP");
        $this->assertEquals("Bia", $d->getNome());
        $this->assertEquals(4000, $d->getSalario());
        $this->assertEquals("PHP", $d->getLinguagemPrincipal());
        $this->assertEquals(48000, $d->calcularSalarioAnual());
    }
}
